public class ConstructorTest {
    ConstructorTest(){

    }

    void setNum(int num){

    }

    
}

class UsingConstructor{
    public static void main(String[] args) {
        
    }
}
