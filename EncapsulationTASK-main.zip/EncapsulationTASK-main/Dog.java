
public class Dog {
        String name;
        int age;
        String color;

        public void bark() {
            System.out.println( name+"can bark");

        }

        public void wag(){
            System.out.println(name+"wags it tails");
        }
        
        public void print_details() {
            System.out.println("Name: "+name+" Age: "+age+" Student Id: "+color);
        }


}
