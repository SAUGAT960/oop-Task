package One Dimensional Array;

public class CalculateValueOfArrayElement {
    public static void main(String[] args) {
        int[] arr = new int[5];
        int sum=0;
        int arrLength = arr.length;
        for (int val:arr);
    }
    
}